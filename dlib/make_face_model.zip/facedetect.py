import cv2
import dlib
import sys
import numpy as np
import time

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor(
    "./shape_predictor_5_face_landmarks.dat"
)


cap = cv2.VideoCapture(cv2.CAP_DSHOW)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 360)
prevTime = 0
while True:
    ret, img = cap.read()
    if not ret:
        break  # 연결안되면 중지

    curTime = time.time()

    # dlib의 detector을 이용해서 얼굴 잡기
    faces = detector(img)
    if faces:

        face = faces[0]  # 잡은 얼굴중 첫번째

        dlib_shape = predictor(img, face)
        shape_2d = np.array(
            [[p.x, p.y] for p in dlib_shape.parts()]
        )  # 얼굴에 68개의 특징점 잡아내기

        img = cv2.rectangle(  # 얼굴 사각형틀로 표시
            img,
            pt1=(face.left(), face.top()),
            pt2=(face.right(), face.bottom()),
            color=(255, 255, 255),
            thickness=2,
            lineType=cv2.LINE_AA,
        )

        for s in shape_2d:  # 특징점 표시
            cv2.circle(
                img,
                center=tuple(s),
                radius=1,
                color=(255, 255, 255),
                thickness=2,
                lineType=cv2.LINE_AA,
            )

    sec = curTime - prevTime
    prevTime = curTime

    fps = 1/(sec)

    # print(f"Time {sec} ")
    print(f"fps : {fps} ")

    cv2.imshow("img", img)
    if cv2.waitKey(1) == ord("q"):
        break
