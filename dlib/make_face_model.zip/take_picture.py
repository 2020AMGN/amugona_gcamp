import cv2

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

cv2.namedWindow("test")

img_counter = 1

while True:
    ret, frame = cap.read()
    if not ret:
        print("오류")
        break
    cv2.imshow("test", frame)

    k = cv2.waitKey(1)
    if k % 256 == 27:
        # ESC
        print("닫음")
        break
    elif k % 256 == 32:
        # SPACE
        img_name = f"picture_{img_counter}.png"
        cv2.imwrite(
            f"./img/{img_name}",
            frame,
        )
        print(f"{img_name} 저장!")
        img_counter += 1

cap.release()

cv2.destroyAllWindows()
